import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PlanetsService } from '../planets.service'; // planet service
import { NgxUiLoaderService } from 'ngx-ui-loader'; // for loader

@Component({
  selector: 'app-planet-details',
  templateUrl: './planet-details.component.html',
  styleUrls: ['./planet-details.component.scss']
})
export class PlanetDetailsComponent implements OnInit {
  id : number;
  sub : any;
  planetDetails : any;
  err : string = "";
  constructor(public planetApi : PlanetsService, public _router:Router, public route:ActivatedRoute, private ngxService: NgxUiLoaderService) { }
/**
 * ngOnInit()
 * call on load function
 */
  ngOnInit() {
    this.ngxService.start();
    this.sub = this.route.params.subscribe(param=>{
      this.id= param['id'];
      if(this.id != undefined && !isNaN(this.id)){
        this.getPlanetDetails();
        this.err = "";
      }else{
        this.err = "Invalid Parameter";
      }
    })
  }
  /**
   * getPlanetDetails()
   * get planet details by id
   */
  getPlanetDetails(){
    this.planetApi.getPlanetDetails(this.id).subscribe(data=>{
      this.planetDetails = data;
      this.ngxService.stop();
    });
  }
  /**
   * goToPlanetList()
   * Navigate to listing page on back button
   */
    goToPlanetList(){
      this._router.navigate(['/list']);
    }
}

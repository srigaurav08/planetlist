import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgxUiLoaderModule } from  'ngx-ui-loader';


import { AppComponent } from './app.component';
import { PlanetDetailsComponent } from './planet-details/planet-details.component';
import { PlanetListComponent } from './planet-list/planet-list.component';
import { HttpClientModule } from '@angular/common/http';
import { PlanetsService } from './planets.service';

const appRoutes: Routes = [
  {
    path: 'list',
    component: PlanetListComponent,
    data: { title: 'Planet List' }
  },
  {
    path: 'details/:id',
    component: PlanetDetailsComponent,
    data: { title: 'Planet Details' }
  },
  {
    path: '',
    redirectTo: '/list',
    pathMatch : 'full'
 },
 {
  path: '**',
  redirectTo: '/list',
  pathMatch : 'full'
}
];

@NgModule({
  declarations: [
    AppComponent,
    PlanetDetailsComponent,
    PlanetListComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
      appRoutes
    ),
    HttpClientModule,
    FormsModule,
    NgxUiLoaderModule
  ],
  providers: [
    PlanetsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

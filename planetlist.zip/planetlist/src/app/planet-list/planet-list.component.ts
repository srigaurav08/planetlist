import { Component, OnInit } from '@angular/core';
import { PlanetsService } from '../planets.service';
import {Router, ActivatedRoute} from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader'; // Import NgxUiLoaderService

@Component({
  selector: 'app-planet-list',
  templateUrl: './planet-list.component.html',
  styleUrls: ['./planet-list.component.scss']
})
export class PlanetListComponent implements OnInit {
  planetList : any = [];
  listLength : number = 0;
  searchTerm : string = "";
    // pager object
    pager: any = {};
    // paged items
    pagedItems: any[];
  constructor(public planetApi : PlanetsService, public _router:Router, private ngxService: NgxUiLoaderService) { }
/**
 * ngOnInit()
 * call on load function
 */
  ngOnInit() {
   this.getPlanetList();
  }
  /**
   * getPlanetList()
   * @param page 
   * fetch planet list by page no.
   */
getPlanetList(page=1){
  this.ngxService.start();
  this.planetApi.getPlaneList(page).subscribe(data=>{
    this.planetList = data;
    this.listLength = (data.results) ? data.results.length : 0;
    this.pager = this.planetApi.getPager(this.planetList.count,page);
    this.ngxService.stop();
  });
}
/**
 * searchPlanet()
 * @param page 
 * search planet list by planet name
 */
  searchPlanet(page=1){
    if(this.searchTerm.length > 0){
      this.planetApi.searchPlaneList(this.searchTerm,page).subscribe(data=>{
        this.planetList = data;
        this.listLength = (data.results) ? data.results.length : 0;
        this.pager = this.planetApi.getPager(this.planetList.count,page);
      });
    }else{
        this.getPlanetList();
    }
  }
  /**
   * setPage()
   * @param page 
   * call as per page selected in pagination
   */
  setPage(page: number) {
    // get pager object from service
    this.pager = this.planetApi.getPager(this.planetList.count, page);
    // get current page of items
    if(this.pager.totalPages >= page && page !=0){
    if(this.searchTerm == "" || this.searchTerm == undefined){
    this.getPlanetList(page);
  }else{
    this.searchPlanet(page);
  }
}
}
/**
 * viewPlanetDetails
 * @param planetObj 
 * call to navigate to planet details page by passing id
 */
viewPlanetDetails(planetObj){
  let url = planetObj.url;
  url = url.replace(/\/$/, "");
  let id = url.substr(url.lastIndexOf('/') + 1); // fetching id from url param because isolated id not present
  this._router.navigate(['/details',id]);

}
}
